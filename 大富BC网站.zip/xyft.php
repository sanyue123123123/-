<?php

ob_start();
$url='http://api.api68.com/pks/getPksHistoryList.do?lotCode=10057';
$contents=file_get_contents($url);
$json=json_decode($contents,true);
$data=$json['result']['data'][0];

$expect=$data['preDrawIssue'];
$opencode=$data['preDrawCode'];
$opentime=$data['preDrawTime'];

header("Content-type: application/json");


echo '{"sign":true,"message":"获取成功","data":[{"title":"北京快乐8","name":"bjkl8","expect":"'.$expect.'","opencode":"'.$opencode.'","opentime":"'.$opentime.'","source":"开彩采集","sourcecode":""}]}';

ob_end_flush();
?>