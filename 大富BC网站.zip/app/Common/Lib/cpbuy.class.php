<?php
namespace Lib;
class cpbuy{
	
}
?>