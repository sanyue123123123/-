<?php
namespace Lib;
class lotterytimes {
	function getdrawtimes($typename){
	}
}
?>