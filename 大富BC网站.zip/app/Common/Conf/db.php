<?php  


 //仅供学习交流 禁止用于任何非法用途  源码来自158501872
return [
	'DB_TYPE'               => 'mysql',
    'DB_HOST'               => '127.0.0.1',
    'DB_NAME'               => 'dflt',
    'DB_USER'               => 'dflt',
    'DB_PWD'                => '3Nsm7d24ymN4rsY7',
    'DB_PREFIX'             => 'caipiao_',
    'DB_PORT'               => '3306',
	'DB_DEBUG'              => false,
	'DB_PARAMS'             => [\PDO::ATTR_CASE => \PDO::CASE_NATURAL],
];
