﻿<?php	

 //仅供学习交流 禁止用于任何非法用途  源码来自
return array (
	'APP_DOMAIN_SUFFIX' => '',
	'APP_SUB_DOMAIN_RULES' => array (

		//PC主页
		//'' => 'Home',//替换你的pc域名
		'ww.dyaxdj.online' => 'Home',//替换你的pc域名
	
		
		'ww.dyaxdj.online'    => 'Mobile',//替换你手机域名
	
		

	),
	'APP_SUB_DOMAIN_DEPLOY' => '1',
);
?>