<?php
//PC版
namespace Common\Controller;
use Think\Controller;
class HomeController extends BaseController {
	public function __construct(){
		parent::__construct();
	}
}