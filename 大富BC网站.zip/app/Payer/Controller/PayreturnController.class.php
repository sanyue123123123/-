<?php
namespace Payer\Controller;
use Think\Controller;
class PayreturnController extends Controller {
    public function _initialize(){
		header("Content-type: text/html; charset=utf-8");
	}
	//智付网银在线
	function dinpay(){
		
	}
	//智付微信在线
	function dinpayweixin(){
		
	}
	
	function hongyu(){
		  $host = $_SERVER['HTTP_HOST'];
		  $host = str_replace('pay.','',$host);
		  redirect("http://".$host);
	}
	
}
?>