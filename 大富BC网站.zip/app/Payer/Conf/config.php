<?php
return array(
	'DEFAULT_FILTER'         =>  'trim,strip_tags,stripslashes',
	'VIEW_PATH'              =>  './Template/payer/',
	//'THEME_LIST'             =>  'default,resources',
	//'DEFAULT_THEME'          =>  'resources',
	'THEME_LIST'             =>  '',
	'DEFAULT_THEME'          =>  '',
	'TMPL_DETECT_THEME'      =>  true,
	'TMPL_FILE_DEPR'         =>  '_',
	'TMPL_TEMPLATE_SUFFIX'   =>  '.php',
);