<?php
return array(
	'DEFAULT_FILTER'         =>  'trim,strip_tags,stripslashes',
	'VIEW_PATH'              =>  './Template/Mobile/',
	'THEME_LIST'             =>  'Mobile',
	'DEFAULT_THEME'          =>  'Mobile',
	'THEME_LIST'             =>  '',
	'DEFAULT_THEME'          =>  '',
	'TMPL_DETECT_THEME'      =>  true,
	'TMPL_FILE_DEPR'         =>  '_',
	'TMPL_TEMPLATE_SUFFIX'   =>  '.php',
	'TMPL_PARSE_STRING'  =>array(
		'__CSS__' => __ROOT__.'/Template/Mobile/css',
		'__FACE__' => __ROOT__.'/Template/Mobile/images/face',
		'__IMG__' => __ROOT__.'/Template/Mobile/images',
		'__JS__' => __ROOT__.'/Template/Mobile/js',
		'__CSS2__' => __ROOT__.'/Template/Mobile/css2',
		'__IMG2__' => __ROOT__.'/Template/Mobile/images2',
		'__JS2__' => __ROOT__.'/Template/Mobile/js2',
		'__UPLOADS__' => __ROOT__.'/Uploads',
	),
);
