<?php
namespace Home\Controller;
use Think\Controller;
class YouhuiController extends CommonController {
	public function __construct(){
		parent::__construct();
	}
}
?>