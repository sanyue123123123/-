<?php
namespace Mobile\Controller;
use Think\Controller;

class VideoController extends CommonController {
	
	public function page(){
		
		$this->display();
	}
		
		
		
}

