<?php
return array(
    'URL_PATHINFO_DEPR'     =>  '/',
	'URL_HTML_SUFFIX'       =>  'do',
	'URL_MODEL'             =>  1,
);