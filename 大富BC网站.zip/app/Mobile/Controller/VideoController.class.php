<?php
namespace Mobile\Controller;

use Think\Controller;
class VideoController extends CommonController {
	
	
	public function login(){ 
		parent::__construct(); 
		$logininfo = islogin();
		if($logininfo['sign']==false){
			session('member_sessionid',NULL);
			session('member_auth_id',NULL);
			redirect(U("Public/login"));
			exit;
		}else{
			if($logininfo['data']['islogin']!=1 || $logininfo['data']['islock']==1){
				session('member_sessionid',NULL);
				session('member_auth_id',NULL);
				redirect(U("Public/login"));
				exit;
			}
			$this->userinfo = $logininfo['data'];
		}

		if(ACTION_NAME !="safepass")
		{
			if(empty($_SESSION['userinfo']['tradepassword']))
			{
				$this->error('为了你的资金安全,请先设置安全密码',U('Member/safepass'));
			}
		}
	}

	
	

	
	public function page($url){
		//var_dump($url);
		$this->login();
		$this->data = $url;
		$this->display();
	}
		
		
		
		//首页视频展示
		public function vod($id){
			
			
			
			$list = M('vod')->where("id > {$id}")->limit(20)->select();
			
			//var_dump($list);
			
			echo json_encode($list);
		}
	
}

